---
date: 2014-03-10
linktitle: Julakan
draft: false
menu:
  main:
    parent: Languages
prev: /tutorials/mathjax
title: Learning Jula
weight: 10
cover_image: "images/image1.jpeg"
#url: /julakan
---


